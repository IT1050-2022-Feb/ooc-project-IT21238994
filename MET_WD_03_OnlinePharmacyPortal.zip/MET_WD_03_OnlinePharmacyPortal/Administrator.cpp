#include "Administrator.h"
#include <cstring>

Reports::Reports(int rNo, const char rName[])
{
	reportNo = rNo;
	strcpy(reportName, rName);
}
void Reports::genarateReport()
{
}
void Reports::ConfirmationMail(const char cusName[], const char cusEmail[])
{
  strcpy(customerName, cusName);
  strcpy(customerEmail, cusEmail);
}
void Reports::sendConfirmationMail()
{
}
Reports::~Reports()
{
}