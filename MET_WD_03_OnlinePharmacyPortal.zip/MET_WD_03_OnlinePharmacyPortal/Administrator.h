class Reports: public Employee
{
private:
	int reportNo;
	char reportName[20];
  char customerName[20];
  char customerEmail[30];
	
public:
	Reports(int rNo, const char rName[]);
	void genarateReport();
  void ConfirmationMail(const char cusName[], const char cusEmail[]);
  void sendConfirmationMail();
	~Reports();
}