#include "Employee.h"
#include <cstring>

Employee::Employee(int eid, const char eName[])
{
	empID = 0;
	strcpy(empName, "");
	strcpy(empEmail, "");
	strcpy(empContactNo,"0000000000");
}
Employee::Employee(int eid, const char eName[])
{
	empID = eid;
	strcpy(empName, eName);
}
void Employee::setEmployeeDetails(const char eEmail[], int eCNo[])
{
}
int Employee::getEmployeeDetails()
{
}
void Employee::displayEmployeeDetails()
{
}
void Employee::calWages(int r, int d)
{
  rate = r;
  days = d;
}
double Employee::displayEmployeeWages()
{
}
Employee::~Employee()
{
}