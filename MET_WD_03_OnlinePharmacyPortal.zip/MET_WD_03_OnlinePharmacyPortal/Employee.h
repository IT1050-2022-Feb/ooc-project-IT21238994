#include "Pharmacist.h"
#include "Administrator.h"
#include "Deliver Staff"
#include "Driver.h"

class Employee
{
protected:
	int empID;
	char empName[20];
	char empEmail[30];
	int empContactNo[10];
	double empWages;
  int rate;
  int days;

public:
	Employee(int eid, const char eName[]);
	void setEmployeeDetails( const char eEmail[], int eCNo[]);
	int getEmployeeDetails();
	void displayEmployeeDetails();
	void calWages(int r, int d);
  double displayEmployeeWages();
	~Employee();
};